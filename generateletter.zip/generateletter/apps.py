from django.apps import AppConfig


class GenerateletterConfig(AppConfig):
    name = 'generateletter'
    verbose_name = "MANAGE"